import asyncio
import logging
import os
import time
import types
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from enum import Enum

from fastmcp import FastMCP
from mlorchsdk import RaptorCallClient
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from pydantic import Field
from starlette.exceptions import HTTPException
from starlette.responses import Response
from starlette.routing import Route

logger = logging.getLogger("uvicorn")
# Define Prometheus metrics
latency_buckets = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 50, 100, 200)
model_request_latency = Histogram('model_request_latency', 'Model Request Latency', ['mcp_server'], buckets=latency_buckets)
model_request_success_count = Counter('model_infer_request_success', 'Model Request Success Count', ['mcp_server'])
model_request_failure_count = Counter('model_infer_request_failure', 'Model Request Failure Count', ['mcp_server'])

BYOA_APP_NAME = os.environ.get("COSMOSAI_BYOA_APP_NAME", "web-inspection")

# Function to inject metrics endpoint
def inject_metrics_endpoint(mcp_instance):
    """Injects a /metrics endpoint into the MCP server."""
    original_sse_app = mcp_instance.sse_app

    async def metrics_endpoint(request):
        return Response(
            content=generate_latest(),
            media_type=CONTENT_TYPE_LATEST,
            headers={'Cache-Control': 'no-store'}
        )

    def patched_sse_app(self):
        app = original_sse_app()
        app.routes.append(Route("/metrics", metrics_endpoint))
        return app

    mcp_instance.sse_app = types.MethodType(patched_sse_app, mcp_instance)


# Initialize MCP server
mcp = FastMCP(
    name="Web Inspection",
    debug=True,
    log_level="DEBUG",
    sse_path=f"/byoa/{BYOA_APP_NAME}/sse",
    message_path=f"/byoa/{BYOA_APP_NAME}/messages/"
)

inject_metrics_endpoint(mcp)


def is_within_n_days(job_date_str, n_days):
    # Parse the jobDate string into a datetime object
    job_date = datetime.strptime(job_date_str, "%Y-%m-%d")
    today = datetime.today()
    thirty_days_from_today = today - timedelta(days=n_days)
    return thirty_days_from_today <= job_date <= today

def is_valid(response):
    return response['jobDate'] and is_within_n_days(response['jobDate'], valid_result_n_days)

def remove_key(d, key):
    return {k: v for k, v in d.items() if k != key}


class ResponseMode(Enum):
    BLOCKING = "blocking"
    NONBLOCKING = "nonblocking"

query_base_url = os.environ.get("QUERY_BASE_URL", "https://www.te-iaodplatform.qa.paypal.com:21777")
web_inspection_base_url = os.environ.get("WEB_INSPECTION_BASE_URL", "https://www.te-iaodplatform.qa.paypal.com:15236")
web_inspection_use_case = os.environ.get("WEB_INSPECTION_USE_CASE", "instant_web_inspection")
source_service = os.environ.get("SOURCE_SERVICE", "compliance_investigation_mate")
web_inspection_service = os.environ.get("WEB_INSPECTION_SERVICE", "")
query_service = os.environ.get("WEB_INSPECTION_QUERY_SERVICE", "")
km_application_context = os.environ.get("KM_APPLICATION_CONTEXT", "")

crawler_max_depth = int(os.environ.get("CRAWLER_MAX_DEPTH", 5))
crawler_max_pages = int(os.environ.get("CRAWLER_MAX_PAGES", 10))
job_status_interval = int(os.environ.get("JOB_STATUS_INTERVAL", 10))
crawler_enable_screenshot = bool(os.environ.get("CRAWLER_ENABLE_SCREENSHOT", False))
crawler_enable_image_download = bool(os.environ.get("CRAWLER_ENABLE_IMAGE_DOWNLOAD", True))
crawler_enable_javascript = bool(os.environ.get("CRAWLER_ENABLE_JAVASCRIPT", True))
valid_result_n_days = int(os.environ.get("VALID_RESULT_N_DAYS", 30))
response_mode = ResponseMode(os.environ.get("RESPONSE_MODE", "nonblocking"))
url_inspecting_message = os.environ.get("URL_INSPECTING_MESSAGE", "Website inspection results will be ready shortly. Feel free to check back in a few minutes!")

@mcp.tool(name="run-website-inspection")
async def run_website_inspection(urls: list[str] = Field(description="the list of website urls to be scanned")) -> dict:
    """
    Run website inspection job for given urls of websites. It provides web inspection capabilities,
    including business model summaries, sample product descriptions, payment options,
    Merchant Category Codes (MCC), and detection of Acceptable Use Policy (AUP) violations.
    """
    logger.info(f"input urls: {urls}")
    try:
        if not urls:
            return {}

        start = time.time()

        inspection_results = get_inspection_results(urls)

        existing_results = [remove_key(r, "violated") for r in inspection_results if is_valid(r)]
        to_inspect_urls = [r['domain'] for r in inspection_results if not is_valid(r)]


        if not to_inspect_urls:
            logger.info(f"no url to inspect, return existing results")
            return {item["domain"]: item for item in existing_results}

        logger.info(f"trigger inspection job: {to_inspect_urls}")
        job_info = trigger_inspection_job(to_inspect_urls)
        logger.info(f"job info: {job_info}")

        if response_mode == ResponseMode.BLOCKING:
            job_status_str = "PROCESSING"
            job_status = {}
            while job_status_str == "PROCESSING":
                await asyncio.sleep(job_status_interval)
                job_status = get_job_status(job_info)
                job_status_str = job_status['status']
                # TODO cancel job when client disconnected

            if job_status_str != "DONE":
                raise Exception(job_status)

            # TODO recover API
            inspection_results = get_inspection_results(to_inspect_urls)
            returning = inspection_results
        elif response_mode == ResponseMode.NONBLOCKING:
            inspecting_message = [{"domain": url, "message": url_inspecting_message} for url in to_inspect_urls]
            returning = inspecting_message
        else:
            raise ValueError(f"invalid response mode {response_mode}")

        model_request_success_count.labels(mcp_server=BYOA_APP_NAME).inc()
        model_request_latency.labels(mcp_server=BYOA_APP_NAME).observe(time.time() - start)
        return {item["domain"]: remove_key(item, "violated") for item in existing_results + returning}
    except Exception as e:
        model_request_failure_count.labels(mcp_server=BYOA_APP_NAME).inc()
        raise e


def get_job_status(job_info):
    status_api_client = RaptorCallClient(
        url=f"{web_inspection_base_url}/v1/compliance/web_inspection/{job_info["id"]}",
        method='get',
        query_params={},
        headers={},
        timeout=5,
        body={},
        source_service=source_service,
        target_service=web_inspection_service,
        km_application_context=km_application_context
    )
    return status_api_client.send_request()


def trigger_inspection_job(to_inspect_urls):
    trigger_api_client = RaptorCallClient(
        url=f"{web_inspection_base_url}/v1/compliance/web_inspection/",
        method='post',
        query_params={},
        headers={},
        timeout=5,
        body={
            "use_case": web_inspection_use_case,
            "params": [
                {
                    "name": "domain_urls",
                    "value": to_inspect_urls
                },
                {
                    "name": "crawl_setting",
                    "value": {
                        "max_depth": crawler_max_depth,
                        "max_pages": crawler_max_pages,
                        "enable_screenshot": crawler_enable_screenshot,
                        "enable_image_download": crawler_enable_image_download,
                        "enable_javascript": crawler_enable_javascript
                    }
                }
            ],
            "creator": "mcp"
        },
        source_service=source_service,
        target_service=web_inspection_service,
        km_application_context=km_application_context
    )
    job_info = trigger_api_client.send_request()
    return job_info


def get_inspection_results(urls):
    responses = []
    with ThreadPoolExecutor() as executor:
        futures = []
        for url in urls:
            query_result_api_client = RaptorCallClient(
                url=f"{query_base_url}/galaxi/api/v5/brm/inspection/instant/",
                method='post',
                query_params={},
                headers={},
                timeout=5,
                body={
                    "domain": url
                },
                source_service=source_service,
                target_service=query_service,
                km_application_context=km_application_context
            )

            futures.append(executor.submit(lambda: query_result_api_client.send_request()))

        for future in as_completed(futures):
            try:
                responses.append(future.result())
            except HTTPException as e:
                raise e
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")

    # daily sar result would sync to on demand table offline
    return responses


if __name__ == "__main__":
    mcp.run(transport='sse', host='0.0.0.0', port=8080)
