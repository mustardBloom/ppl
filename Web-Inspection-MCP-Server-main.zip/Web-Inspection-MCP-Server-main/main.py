def main():
    print("Hello from my-mcp-server!")


if __name__ == "__main__":
    main()
