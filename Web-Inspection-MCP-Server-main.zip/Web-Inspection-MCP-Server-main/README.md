# Demo Project for Web Inspection MCP Server

## Development

Set up the environment

```
uv venv
source .venv/bin/activate
```

Install the MCP SDK

```
uv add "mcp[cli]"
```

Run

```
uv run server.py
```

Investigate through MCP Inspector
```
npx @modelcontextprotocol/inspector
```

## Deploy to the BYOA (Bring Your Own App) platform


Build the docker image

```
docker build -t my-mcp-server .
```

Dependencies: If your server requires additional Python packages, you can modify the Dockerfile to install them
```
FROM dockerhub.paypalcorp.com/aiplatform/mcp-server-base:20250416

COPY server.py /app/server.py

**Install additional dependencies**
RUN uv add [your-package] --extra-index-url https://artifactory.paypalcorp.com/artifactory/api/pypi/paypal-python-all/simple

ENTRYPOINT ["uv", "run", "server.py"]
```

Test the docker image locally

```
docker run -p 8000:8000 my-mcp-server
```

Push the docker image to docker hub

```
docker tag my-mcp-server dockerhub.paypalcorp.com/aiplatform/cipds/web-inspection-mcp-server:[latest version]
docker push dockerhub.paypalcorp.com/aiplatform/cipds/web-inspection-mcp-server:[latest version]
```
Replace [latest version] with your desired version number (like 0.0.1)

### Env Variables in Production

```
CURRENT_PROFILE=prod
WEB_INSPECTION_BASE_URL=https://compmediasearchserv.g.uswest.paypalinc.com:13898
QUERY_BASE_URL=https://galaxibrmapiserv.g.uswest.paypalinc.com:16135
WEB_INSPECTION_SERVICE=compmediasearchserv
WEB_INSPECTION_QUERY_SERVICE=galaxibrmapiserv
```

